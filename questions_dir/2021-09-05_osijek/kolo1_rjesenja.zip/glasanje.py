N = int(input())
M = int(input())

L = [0] * N

for i in range(M):
    A, B = map(int, input().split())

    L[A - 1] += B

print(L.index(max(L)) + 1)
