X = int(input())
M = int(input())

if X == M:
    print('DA')
else:
    print('NE')
